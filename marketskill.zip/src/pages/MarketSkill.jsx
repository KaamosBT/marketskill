import { useState } from "react";

export default function MarketSkill() {
  const [pageData, setPageData] = useState({
    name: "",
    description: "",
    service: "",
    price: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPageData({ ...pageData, [name]: value });
  };

  const handleSubmit = () => {
    alert("Página criada com sucesso! Veja como ficou abaixo.");
  };

  return (
    <div className="p-6 max-w-4xl mx-auto font-sans">
      <h1 className="text-3xl font-bold mb-6">MarketSkill - Crie sua página de serviços</h1>

      <div className="mb-4">
        <input name="name" className="w-full p-2 border rounded mb-2" placeholder="Seu nome ou nome da marca" value={pageData.name} onChange={handleChange} />
        <textarea name="description" className="w-full p-2 border rounded mb-2" placeholder="Descrição do que você faz" value={pageData.description} onChange={handleChange} />
        <input name="service" className="w-full p-2 border rounded mb-2" placeholder="Serviço oferecido (ex: aula de violão)" value={pageData.service} onChange={handleChange} />
        <input name="price" className="w-full p-2 border rounded mb-2" placeholder="Preço (ex: R$ 50/hora)" value={pageData.price} onChange={handleChange} />
        <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={handleSubmit}>Criar Página</button>
      </div>

      <div className="p-4 bg-gray-100 rounded shadow">
        <h2 className="text-2xl font-semibold mb-2">{pageData.name || "Seu Nome Aqui"}</h2>
        <p className="mb-2 text-gray-600">{pageData.description || "Descrição do seu serviço."}</p>
        <p><strong>Serviço:</strong> {pageData.service || "(ex: Consultoria)"}</p>
        <p><strong>Preço:</strong> {pageData.price || "(ex: R$ 100 por hora)"}</p>
      </div>
    </div>
  );
}